//
//  APIManager.swift
//  MowebWebApiClasses
//
//  Created by Ankit Patel on 08/01/19.
//  Copyright © 2019 Ankit Patel. All rights reserved.
//

import UIKit

public typealias APIManagerSuccessHandler = ((Data) -> Void)
public typealias APIManagerDownloadSuccessHandler = ((URL) -> Void)
public typealias APIManagerFailureHandler = ((String) -> Void)
public typealias APIManagerNoInternetConnectionHandler = (() -> Void)

class APIManager: NSObject {
    
    //MARK: ---- All ClassObject ----
    static let shared = APIManager()
    private var reachability: Reachability?
    private var isInternetReachable : Bool = false
    
    private var postApiInProgress: Int = 0
    private var postAttachmentApiInProgress: Int = 0
    
    static var generalServerError: String = ""
    static var generalNoInternetError: String = ""
    static var commonAPIRequestParameters: Parameters = Parameters()
    static var headerkey: String = ""
    static var timeoutInterval: Double = 60.0
    static var apiFailureRetryViewParent: UIView? = nil
    
    private let apiFailureRetryViewTag: Int = 121223322
    
    /*
     onSuccessHandler -> Will be called on successful response checking
     onFailureHandler (optional) -> Will be called when an error is occured, it will be directly haldled from api but if an view controller wants seperate implementation
     noInternetAccess (optional) -> to reload tables or make any view active
     */
    
    override init() {
        super.init()
        
        self.setupReachability()
    }
    
    func download(from destinationURL: String,
                  fromViewController: UIViewController,
                  shouldShowProgress: Bool = true,
                  onSuccessHandler: @escaping APIManagerDownloadSuccessHandler,
                  onFailureHandler: APIManagerFailureHandler?,
                  noInternetAccess: APIManagerNoInternetConnectionHandler?) -> Void {

        let attachmentURL = URL(string: destinationURL)!

        let tempDirectoryURL = NSURL.fileURL(withPath: NSTemporaryDirectory(), isDirectory: true)

        let targetURL = tempDirectoryURL.appendingPathComponent(attachmentURL.lastPathComponent)

        if FileManager.default.fileExists(atPath: targetURL.path) {
            onSuccessHandler(targetURL)
            return
        }

        if isInternetReachable {

            if shouldShowProgress {
                fromViewController.showProgressHud()
            }

            let session = URLSession(configuration: URLSessionConfiguration.default, delegate: nil, delegateQueue: nil)
            var request = URLRequest(url: attachmentURL)
            request.addValue("close", forHTTPHeaderField: "Connection")
            request.httpMethod = HttpMethod.get.rawValue


            let task = session.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) -> Void in
                DispatchQueue.main.async(execute: {
                    fromViewController.hideProgressHud()

                    if let error = error {
                        onFailureHandler?(error.localizedDescription)
                        print("error \(String(describing: (response as? HTTPURLResponse)?.statusCode))")
                        return
                    }

                    if let response = response as? HTTPURLResponse,
                        response.statusCode == 200,
                        let data = data,
                        let _ = try? data.write(to: targetURL, options: Data.WritingOptions.atomic) {

                        onSuccessHandler(targetURL)
                    } else {
                        if let response = response as? HTTPURLResponse {
                            response.printLogs()
                        }

                        onFailureHandler?(APIManager.generalServerError)
                    }
                    return
                })
            }
            task.resume()
        } else {
            DispatchQueue.main.async(execute: {
                fromViewController.hideProgressHud()
                fromViewController.showAlert(message: APIManager.generalNoInternetError)
                noInternetAccess?()
                return
            })
        }
    }
    
    func post(_ urlString: String,
              requestBody: Parameters,
              fromViewController: UIViewController,
              shouldShowApiFailureRetryScreen: Bool = false,
              onSuccessHandler: @escaping APIManagerSuccessHandler,
              onFailureHandler: APIManagerFailureHandler? = nil,
              noInternetAccess: APIManagerNoInternetConnectionHandler? = nil) -> Void {
        
        let finalURL = URL(string: urlString)
        
        let paramsToSend = mergeCommonParameters(requestBody)
        
        //making request
        var request: URLRequest = URLRequest(url: finalURL!)
        request.setValue(paramsToSend.makeSHA256(), forHTTPHeaderField: "X-Hash")
        request.setValue("application/x-www-form-urlencoded; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.addValue("close", forHTTPHeaderField: "Connection")
        request.httpBody = paramsToSend.getQueryString().data(using: .utf8)
        request.httpMethod = HttpMethod.post.rawValue
        request.timeoutInterval = APIManager.timeoutInterval
        request.cachePolicy = .reloadIgnoringCacheData
        
        if isInternetReachable {
            postApiInProgress += 1
            fromViewController.showProgressHud()
            let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) -> Void in
                DispatchQueue.main.async(execute: {
                    
                    self.postApiInProgress -= 1
                    
                    if self.postApiInProgress <= 0 {
                        fromViewController.hideProgressHud()
                    }
                    
                    if let error = error {
                        onFailureHandler?(error.localizedDescription)
                        
                        if shouldShowApiFailureRetryScreen {
                            _ = self.addAPIFailureRetryView(onRetryTapped: {
                                 self.post(urlString, requestBody: requestBody,fromViewController: fromViewController, shouldShowApiFailureRetryScreen: shouldShowApiFailureRetryScreen, onSuccessHandler: onSuccessHandler, onFailureHandler: onFailureHandler, noInternetAccess: noInternetAccess)
                            })
                        }
                        return
                    }
                    
                    if let response = response as? HTTPURLResponse,
                        response.statusCode == 200,
                        let data = data {
                        data.printUTF8()
                        
                        onSuccessHandler(data)
                        self.removeAPIFailureRetryView()
                    } else {
                        if let response = response as? HTTPURLResponse {
                            response.printLogs()
                        }
                        
                        onFailureHandler?(APIManager.generalServerError)
                        if shouldShowApiFailureRetryScreen {
                            _ = self.addAPIFailureRetryView(onRetryTapped: {
                                self.post(urlString, requestBody: requestBody,fromViewController: fromViewController, shouldShowApiFailureRetryScreen: shouldShowApiFailureRetryScreen, onSuccessHandler: onSuccessHandler, onFailureHandler: onFailureHandler, noInternetAccess: noInternetAccess)
                            })
                        }
                    }
                    return
                })
            }
            task.resume()
        } else {
            DispatchQueue.main.async(execute: {
                fromViewController.hideProgressHud()
                fromViewController.showAlert(message: APIManager.generalNoInternetError)
                noInternetAccess?()
                if shouldShowApiFailureRetryScreen {
                    _ = self.addAPIFailureRetryView(onRetryTapped: {
                        self.post(urlString, requestBody: requestBody,fromViewController: fromViewController, shouldShowApiFailureRetryScreen: shouldShowApiFailureRetryScreen, onSuccessHandler: onSuccessHandler, onFailureHandler: onFailureHandler, noInternetAccess: noInternetAccess)
                    })
                }
                return
            })
        }
    }
    
    func post(_ urlString: String,
              requestBody: Parameters,
              mediaFiles: [APIManagerMediaFile],
              fromViewController: UIViewController,
              shouldShowApiFailureRetryScreen: Bool = false,
              onSuccessHandler: @escaping APIManagerSuccessHandler,
              onFailureHandler: APIManagerFailureHandler? = nil,
              noInternetAccess: APIManagerNoInternetConnectionHandler? = nil) -> Void {
        
        let paramsToSend = mergeCommonParameters(requestBody)
        
        let multiPartURLRequest = APIManagerMultiPartFileRequest(urlString, paramters: paramsToSend, mediaFiles: mediaFiles)

        if isInternetReachable {
            fromViewController.showProgressHud()

            postAttachmentApiInProgress += 1

            let task = URLSession.shared.dataTask(with: multiPartURLRequest.request!) {
                (data: Data?, response: URLResponse?, error: Error?) -> Void in
                DispatchQueue.main.async(execute: {

                    self.postAttachmentApiInProgress -= 1

                    if self.postAttachmentApiInProgress <= 0 {
                        fromViewController.hideProgressHud()
                    }

                    if let error = error {
                        onFailureHandler?(error.localizedDescription)
                        print("error \(String(describing: (response as? HTTPURLResponse)?.statusCode))")
                        return
                    }

                    if let response = response as? HTTPURLResponse,
                        response.statusCode == 200,
                        let data = data {
                        data.printUTF8()

                        onSuccessHandler(data)
                    } else {
                        if let response = response as? HTTPURLResponse {
                            response.printLogs()
                        }
                        onFailureHandler?(APIManager.generalServerError)
                    }
                    return
                })
            }
            task.resume()
        } else {
            DispatchQueue.main.async(execute: {
                fromViewController.hideProgressHud()
                fromViewController.showAlert(message: APIManager.generalNoInternetError)
                noInternetAccess?()
                return
            })
        }
    }
    
    private func setupReachability() {
        reachability = Reachability()
        if reachability?.connection != .none {
            isInternetReachable = true
        } else {
            isInternetReachable = false
        }
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(reachabilityChanged(_:)),
                                               name: .reachabilityChanged, object:reachability)
        do {
            try reachability?.startNotifier()
        } catch {
            print("could not start reachability notifier")
        }
    }
    
    @objc func reachabilityChanged(_ note: Notification) {
        let reachability = note.object as! Reachability
        if reachability.connection != .none {
            isInternetReachable = true
        } else {
            isInternetReachable = false
        }
    }
    
}

extension APIManager {
    func addAPIFailureRetryView(onRetryTapped: @escaping SimpleClickHandler) -> Bool {
        
        guard let parentView = APIManager.apiFailureRetryViewParent else {
            return false
        }
        
        if let existingRetryView = parentView.viewWithTag(apiFailureRetryViewTag) as? APIFailureRetryView {
            existingRetryView.retryClickHandler = onRetryTapped
            print("Updating APIFailureRetryView with tag: \(apiFailureRetryViewTag)")
        } else {
            let retryView = APIFailureRetryView()
            retryView.tag = apiFailureRetryViewTag
            retryView.retryClickHandler = onRetryTapped
            retryView.addToParentView(parentView: parentView, newTag: apiFailureRetryViewTag)
            print("Adding APIFailureRetryView with tag: \(apiFailureRetryViewTag)")
        }
        
        return true
    }
    
    func removeAPIFailureRetryView() {
        guard let parentView = APIManager.apiFailureRetryViewParent else {
            return
        }
        
        if let existingRetryView = parentView.viewWithTag(apiFailureRetryViewTag) as? APIFailureRetryView {
            existingRetryView.removeFromSuperview()
        }
    }
}

extension APIManager {
    func mergeCommonParameters(_ param : Parameters) -> Parameters {
        var returnValue : Parameters = APIManager.commonAPIRequestParameters
        returnValue.merge(dict: param)
        return returnValue
    }
}
