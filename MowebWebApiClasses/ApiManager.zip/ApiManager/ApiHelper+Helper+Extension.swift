//
//  ApiHelper+Extension.swift
//  MowebWebApiClasses
//
//  Created by Ankit Patel on 08/01/19.
//  Copyright © 2019 Ankit Patel. All rights reserved.
//

import UIKit
import CommonCrypto

public typealias Parameters = [String: Any]
public typealias SimpleClickHandler = (() -> Void)

public enum HttpMethod : String {
    case get = "GET"
    case post = "POST"
    case put = "PUT"
    case delete = "DELETE"
}


struct APIManagerMediaFile {
    let fileApiParamKey: String?
    let fileName: String?
    var fileData: Data?
    let fileMimeType: String?
    
    init(fileApiParamKey: String, fileName: String, fileData: Data) {
        self.fileApiParamKey = fileApiParamKey
        self.fileName = fileName
        self.fileData = fileData
        self.fileMimeType = fileData.mimeType
    }
}


class APIManagerMultiPartFileRequest: NSObject {
    
    public var request : URLRequest!
    public var hashBody: Data?
    
    public init(_ requestURLString: String,
                paramters: Parameters,
                mediaFiles: [APIManagerMediaFile]) {
        
        super.init()
        
        guard let finalURL = URL(string: requestURLString) else { return }
        request = URLRequest(url: finalURL)
        request.httpMethod = HttpMethod.post.rawValue
        let boundary = generateBoundary()
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        request?.httpBody = createMultipartDataBody(withParameters: paramters, mediaFiles: mediaFiles, boundary: boundary)
        
        request.setValue(paramters.makeSHA256(), forHTTPHeaderField: "X-Hash")
        request.addValue("close", forHTTPHeaderField: "Connection")
        request.addValue("Client-ID f65203f7020dddc", forHTTPHeaderField: "Authorization") // ---- Testing code
    }
    
    private func generateBoundary() -> String {
        return "Boundary-\(NSUUID().uuidString)"
    }
    
    private func createMultipartDataBody(withParameters params: Parameters?, mediaFiles: [APIManagerMediaFile], boundary: String) -> Data {
        
        let lineBreak = "\r\n"
        var body = Data()
        
        if let parameters = params {
            for (key, value) in parameters {
                body.append(string:"--\(boundary + lineBreak)")
                body.append(string:"Content-Disposition: form-data; name=\"\(key)\"\(lineBreak + lineBreak)")
                body.append(string:"\(String(describing: value) + lineBreak)")
            }
        }
        
        hashBody = body
        
        
        for fileDetail in mediaFiles {
            if let parameterKey = fileDetail.fileApiParamKey, let fileName = fileDetail.fileName, let fileData = fileDetail.fileData, let fileMimeType = fileDetail.fileMimeType, fileData.count > 0 {
                body.append(string:"--\(boundary + lineBreak)")
                body.append(string:"Content-Disposition: form-data; name=\"\(parameterKey)\"; filename=\"\(fileName)\"\(lineBreak)")
                body.append(string:"Content-Type: \(fileMimeType + lineBreak + lineBreak)")
                body.append(fileData)
                body.append(string:lineBreak)
            }
        }
        
        body.append(string:"--\(boundary)--\(lineBreak)")
        
        return body
    }
}


extension UIViewController{
    
    public func showProgressHud(withTintColor progressTintColor: UIColor? = nil, withLoadingMessage: String? = nil) {
        
    }
    
    public func hideProgressHud() {
        
    }
    
    func showAlert(message: String) {
        
    }
}


extension HTTPURLResponse {
    func printLogs() {
        print("----- Failure Request Logs-----")
        print("Request URL: \(String(describing: self.url))")
        print("Code: \(self.statusCode)")
        print("----------")
    }
}

extension Data {
    mutating func append(string: String) {
        if let data = string.data(using: .utf8) {
            append(data)
        }
    }
    
    func printUTF8() {
        print("----- Data String UTF8 -----")
        print(String.init(data: self, encoding: .utf8)!)
    }
    
    func makeSHA256() -> String {
        guard let jsonData = try? JSONSerialization.jsonObject(with: self, options: .allowFragments),
            let jsonObject = jsonData as? Parameters else {
                //fatalError("Wrong Json")
                return ""
        }
        
        return jsonObject.makeSHA256()
    }
}

extension Data {
    private static let mimeTypeSignatures: [UInt8 : String] = [
        0xFF : "image/jpeg",
        0x89 : "image/png",
        0x47 : "image/gif",
        0x49 : "image/tiff",
        0x4D : "image/tiff",
        0x25 : "application/pdf",
        0xD0 : "application/vnd",
        0x46 : "text/plain",
        ]
    
    var mimeType: String {
        var c: UInt8 = 0
        copyBytes(to: &c, count: 1)
        return Data.mimeTypeSignatures[c] ?? "application/octet-stream"
    }
}

extension String {
    func ccSha256() -> String{
        if let stringData = self.data(using: String.Encoding.utf8) {
            return hexStringFromData(input: digest(input: stringData as NSData))
        }
        return ""
    }
    
    private func digest(input : NSData) -> NSData {
        let digestLength = Int(CC_SHA256_DIGEST_LENGTH)
        var hash = [UInt8](repeating: 0, count: digestLength)
        CC_SHA256(input.bytes, UInt32(input.length), &hash)
        return NSData(bytes: hash, length: digestLength)
    }
    
    private  func hexStringFromData(input: NSData) -> String {
        var bytes = [UInt8](repeating: 0, count: input.length)
        input.getBytes(&bytes, length: input.length)
        
        var hexString = ""
        for byte in bytes {
            hexString += String(format:"%02x", UInt8(byte))
        }
        
        return hexString
    }
}

extension Dictionary {
    mutating func merge(dict: [Key: Value]){
        for (k, v) in dict {
            updateValue(v, forKey: k)
        }
    }
    
    func makeSHA256() -> String {
        guard let jsonData = try? JSONSerialization.data(withJSONObject: self, options: []),
            let jsonString = String.init(data: jsonData, encoding: .utf8) else {
                //fatalError("Wrong Json")
                return ""
        }
        
        print("----- SHA256 START -----")
        print("----- BODY -----")
        print(jsonString.filter { !"\n\t\r".contains($0) })
        let json256 = jsonString.filter { !"\n\t\r".contains($0) }.ccSha256()
        print("----- BODY ccSha256 -----")
        print(json256)
        print("----- SHA256 END -----")
        return json256
    }
    
    func getQueryString() -> String {
        var data = [String]()
        for(key, value) in self {
            data.append(String(describing: key) + "=\(value)")
        }
        return data.map { String($0) }.joined(separator: "&")
    }
}

extension Collection {
    
    /// Returns the element at the specified index iff it is within bounds, otherwise nil.
    subscript (safe index: Index) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}

