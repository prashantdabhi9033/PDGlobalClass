//
//  APIFailureRetryView.swift
//  MowebWebApiClasses
//
//  Created by Ankit Patel on 08/01/19.
//  Copyright © 2019 Ankit Patel. All rights reserved.
//

import UIKit

@IBDesignable
class APIFailureRetryView: UIView, NibLoadable {
    
    
    public var retryClickHandler: SimpleClickHandler?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.commonInit()
    }
    
    private func commonInit() {
        setupFromNib()
    }
    
    @IBAction func retryTapped(_ sender: Any) {
        self.retryClickHandler?()
    }
}


extension APIFailureRetryView {
    func addToParentView(parentView: UIView, newTag: Int) {
        self.tag = newTag
        self.translatesAutoresizingMaskIntoConstraints = false
        parentView.addSubview(self)
        self.leftAnchor.constraint(equalTo: parentView.leftAnchor).isActive = true
        self.rightAnchor.constraint(equalTo: parentView.rightAnchor).isActive = true
        self.topAnchor.constraint(equalTo: parentView.topAnchor).isActive = true
        self.bottomAnchor.constraint(equalTo: parentView.bottomAnchor).isActive = true
    }
    
}
